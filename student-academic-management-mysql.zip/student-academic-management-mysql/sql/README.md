# SQL scripts

This folder contains the executable database scripts, in setup order.

## Files

| File | Description |
| --- | --- |
| `01_create_database_and_schema.sql` | Creates `college_db`, selects it, and creates the eight tables and their constraints. |
| `02_insert_sample_data.sql` | Inserts 20 sample rows into each table. |
| `03_queries_13_to_34_answers.sql` | Contains query answers 13–34, plus a view, transaction examples, and index statements. |

## Safe run order

Run scripts 01 and 02 once against a fresh database. The table-creation and insert statements are not designed to be rerun: existing tables or duplicate primary keys will cause errors.

The answer file starts with `USE college_db;`. It is an educational answer set rather than a read-only batch. Review each numbered section before executing it:

- **Question 17** filters for `S101`, but the sample IDs are `S001`–`S020`. Change the filter to a seeded ID to see a row.
- **Question 18** filters for `Database Systems`, while the sample course is named `Database Management`. Use the sample name in the filter to get the expected faculty row.
- **Question 25** finds students enrolled in more than one course. In the sample data, only `S001` has multiple enrollments.
- **Question 26** finds attendance below 75%. All provided sample attendance rates are at least 75%, so this query returns no students on the sample rows.
- **Question 28** looks for courses with more than 30 enrolled students. The sample has only 20 enrollments total, so the result is empty.
- **Question 29** compares each student's marks with their department average. There is one sample student in each department, so no student is above their own department's average.
- **Question 33** commits an update to `S001` / `C001`, changing its marks to `38, 39, 57`. Its later rollback only reverses the second, uncommitted update; it does not undo the earlier commit.
- **Question 34** creates three indexes. Re-running those statements will fail if the named indexes already exist. Also check existing primary, unique, and foreign-key indexes first; some of these student-column indexes may duplicate indexes already available from the schema.

Question 32 creates or replaces the `StudentPerformance` view. The CTEs and window functions in the answer set require MySQL 8.0; enforced `CHECK` constraints require MySQL 8.0.16 or later.

## Example CLI setup

Run from the repository root:

```bash
mysql -u root -p < sql/01_create_database_and_schema.sql
mysql -u root -p college_db < sql/02_insert_sample_data.sql
```

For an individual query section, connect to the database and execute only the selected section from `03_queries_13_to_34_answers.sql`.
