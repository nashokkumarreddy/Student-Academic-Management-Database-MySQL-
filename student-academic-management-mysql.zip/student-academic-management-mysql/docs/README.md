# Database documentation

## Entity relationship diagram

The image `WhatsApp Image 2026-10-08 at 3.10.50 PM.jpeg` is the supplied conceptual ER diagram for the student academic management database. It shows departments, students, faculty, courses, teaching/course offerings, enrollments, attendance, and marks.

## How the diagram maps to the SQL

- `DEPARTMENT` maps to `departments`; its one-to-many relationships map to the `d_id` foreign keys in `students`, `faculty`, and `course`.
- The diagram's `TEACHES` relationship, with `offering_id` and `semester`, is implemented as the `course_offering` table. It points to one course and one faculty member.
- Student-course enrollment is implemented as `enrollment`, with its own `enrollment_id` and a uniqueness rule on `(s_id, c_id, semester)`.
- The diagram draws `ATTENDANCE` and `MARKS` as dependent on `ENROLLMENT`. In the SQL, each table instead uses `(s_id, c_id)` as its composite primary key and has separate foreign keys to `students` and `course`. There is no `enrollment_id` foreign key or semester column in those tables.

That last difference means the diagram and SQL schema are not a perfect one-to-one mapping. If a student can retake a course and needs a separate record per semester, attendance and marks should be keyed to an enrollment or include semester in their keys.
